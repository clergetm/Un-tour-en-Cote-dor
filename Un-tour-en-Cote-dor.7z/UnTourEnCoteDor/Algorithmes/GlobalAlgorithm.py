from Algorithmes.Algorithm import Algorithm


class GlobalAlgorithm(Algorithm):
    def __init__(self):
        super().__init__("Recherche Locale","Algo Global")


